# 💰 FinançasPro

Gestão financeira pessoal conectada ao Supabase.

## 🚀 Deploy na Vercel (2 minutos, grátis)

### Opção 1 — Via GitHub (recomendado)
1. Crie uma conta em https://github.com e faça upload desta pasta
2. Acesse https://vercel.com e clique **"Add New Project"**
3. Conecte o repositório GitHub
4. Em **Environment Variables**, adicione:
   - `VITE_SUPABASE_URL` = `https://hasdsnvlhoqoekyfbhkk.supabase.co`
   - `VITE_SUPABASE_KEY` = `sb_publishable_oEJQTqNsXOQkWZo7STJp6w_Dl2dZuzI`
5. Clique **Deploy** ✅

### Opção 2 — Via Vercel CLI
```bash
npm install -g vercel
cd financaspro
npm install
vercel
```

## 💻 Rodar localmente
```bash
npm install
npm run dev
# Abre em http://localhost:5173
```

## 📁 Estrutura
```
financaspro/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx       # Entry point
    ├── App.jsx        # App completo (todas as telas)
    └── supabase.js    # Cliente Supabase
```

## 🗄️ Banco de dados
Já configurado no Supabase (personal-project):
- `user_profiles` — perfil e metas %
- `categories` — categorias de receita/despesa
- `monthly_periods` — períodos mensais
- `transactions` — lançamentos (previsto vs real)
- `investments` — aplicações financeiras
- `financial_goals` — metas com progresso
- Views `monthly_summary` e `monthly_balance`
