import { useState, useEffect, useCallback } from 'react'
import { supabase } from './supabase'

// ─── Utils ────────────────────────────────────────────────────────────────────
const fmt = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0)
const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
const MONTH_NAMES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
  'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']

// ─── Theme ────────────────────────────────────────────────────────────────────
const T = {
  bg:'#0f1117', surface:'#181c27', surface2:'#1e2335', border:'#272d42',
  green:'#3ecf8e', red:'#f87171', yellow:'#fbbf24', blue:'#60a5fa',
  text:'#e2e8f0', muted:'#64748b', muted2:'#94a3b8',
}
const s = {
  page:{ minHeight:'100vh', background:T.bg, fontFamily:'system-ui,sans-serif', color:T.text },
  card:{ background:T.surface, border:`1px solid ${T.border}`, borderRadius:12, padding:20 },
  input:{ width:'100%', background:T.surface2, border:`1px solid ${T.border}`, borderRadius:8,
    padding:'10px 12px', color:T.text, fontSize:13, fontFamily:'inherit', outline:'none' },
  label:{ fontSize:11, color:T.muted, textTransform:'uppercase', letterSpacing:1, marginBottom:6, display:'block' },
  btnP:{ background:T.green, color:'#0f1117', fontWeight:700, fontSize:13, padding:'10px 20px',
    borderRadius:8, border:'none', cursor:'pointer', fontFamily:'inherit' },
  btnS:{ background:'transparent', color:T.muted2, fontWeight:500, fontSize:13, padding:'10px 20px',
    borderRadius:8, border:`1px solid ${T.border}`, cursor:'pointer', fontFamily:'inherit' },
  mono:{ fontFamily:'monospace' },
}

// ─── Auth ─────────────────────────────────────────────────────────────────────
function AuthScreen({ onAuth }) {
  const [tab, setTab] = useState('login')
  const [form, setForm] = useState({ email:'', password:'', name:'' })
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')

  const handle = async () => {
    if (!form.email || !form.password) { setErr('Preencha e-mail e senha.'); return }
    setLoading(true); setErr('')
    try {
      let error, data
      if (tab === 'login') {
        ({ data, error } = await supabase.auth.signInWithPassword({ email: form.email, password: form.password }))
      } else {
        ({ data, error } = await supabase.auth.signUp({
          email: form.email, password: form.password,
          options: { data: { full_name: form.name } }
        }))
      }
      if (error) throw error
      if (data?.user) onAuth(data.user)
    } catch (e) { setErr(e.message) }
    setLoading(false)
  }

  return (
    <div style={{ ...s.page, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ width:'100%', maxWidth:400 }}>
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ fontSize:40, marginBottom:8 }}>💰</div>
          <h1 style={{ fontSize:24, fontWeight:700, color:'#fff' }}>FinançasPro</h1>
          <p style={{ color:T.muted2, fontSize:13, marginTop:4 }}>Gestão financeira pessoal</p>
        </div>
        <div style={s.card}>
          <div style={{ display:'flex', background:T.surface2, borderRadius:8, padding:4, marginBottom:20 }}>
            {['login','register'].map(t => (
              <button key={t} onClick={() => { setTab(t); setErr('') }}
                style={{ flex:1, padding:'8px 0', borderRadius:6, fontSize:13, fontWeight:600, cursor:'pointer',
                  background:tab===t?T.green:'transparent', color:tab===t?'#0f1117':T.muted2, border:'none' }}>
                {t==='login'?'Entrar':'Criar conta'}
              </button>
            ))}
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {tab==='register' && (
              <div><label style={s.label}>Nome</label>
                <input style={s.input} placeholder="Seu nome" value={form.name}
                  onChange={e => setForm({...form, name:e.target.value})} />
              </div>
            )}
            <div><label style={s.label}>E-mail</label>
              <input style={s.input} type="email" placeholder="seu@email.com" value={form.email}
                onChange={e => setForm({...form, email:e.target.value})} />
            </div>
            <div><label style={s.label}>Senha</label>
              <input style={s.input} type="password" placeholder="••••••••" value={form.password}
                onChange={e => setForm({...form, password:e.target.value})}
                onKeyDown={e => e.key==='Enter' && handle()} />
            </div>
            {err && <div style={{ color:T.red, fontSize:12, background:'rgba(248,113,113,.1)', padding:'8px 12px', borderRadius:6 }}>{err}</div>}
            <button onClick={handle} disabled={loading}
              style={{ ...s.btnP, width:'100%', opacity:loading?.6:1 }}>
              {loading ? 'Aguarde...' : tab==='login' ? 'Entrar' : 'Criar conta'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const NAV = [
  {id:'dashboard',icon:'📊',label:'Dashboard'},
  {id:'transactions',icon:'💸',label:'Transações'},
  {id:'investments',icon:'📈',label:'Aplicações'},
  {id:'goals',icon:'🎯',label:'Metas'},
  {id:'reports',icon:'📋',label:'Relatórios'},
  {id:'settings',icon:'⚙️',label:'Config'},
]

function Sidebar({ active, setActive, onLogout, collapsed, setCollapsed }) {
  return (
    <div style={{ width:collapsed?56:210, background:T.surface, borderRight:`1px solid ${T.border}`,
      display:'flex', flexDirection:'column', height:'100vh', position:'fixed', top:0, left:0, zIndex:100,
      transition:'width .2s' }}>
      <div style={{ padding:collapsed?'16px 0':'16px 14px', borderBottom:`1px solid ${T.border}`,
        display:'flex', alignItems:'center', justifyContent:collapsed?'center':'space-between' }}>
        {!collapsed && <span style={{ fontWeight:700, fontSize:14, color:'#fff' }}>💰 FinançasPro</span>}
        <button onClick={() => setCollapsed(!collapsed)}
          style={{ color:T.muted, fontSize:16, padding:4, cursor:'pointer', background:'none', border:'none' }}>
          {collapsed?'›':'‹'}
        </button>
      </div>
      <nav style={{ flex:1, padding:'10px 6px' }}>
        {NAV.map(n => (
          <button key={n.id} onClick={() => setActive(n.id)}
            style={{ width:'100%', display:'flex', alignItems:'center', gap:collapsed?0:10,
              padding:collapsed?'10px 0':'9px 10px', justifyContent:collapsed?'center':'flex-start',
              borderRadius:8, marginBottom:2, cursor:'pointer',
              background:active===n.id?T.green+'22':'transparent',
              color:active===n.id?T.green:T.muted2, fontWeight:active===n.id?600:400,
              fontSize:13, border:'none' }}>
            <span style={{ fontSize:16 }}>{n.icon}</span>
            {!collapsed && <span>{n.label}</span>}
          </button>
        ))}
      </nav>
      <div style={{ padding:collapsed?'10px 0':'10px 8px', borderTop:`1px solid ${T.border}` }}>
        <button onClick={onLogout}
          style={{ width:'100%', padding:collapsed?'8px 0':'8px 10px', borderRadius:6, cursor:'pointer',
            background:'rgba(248,113,113,.1)', color:T.red, fontSize:12, border:'none',
            display:'flex', alignItems:'center', gap:6, justifyContent:collapsed?'center':'flex-start' }}>
          <span>🚪</span>{!collapsed && 'Sair'}
        </button>
      </div>
    </div>
  )
}

// ─── Shared ───────────────────────────────────────────────────────────────────
function KPI({ label, value, sub, color=T.green, icon }) {
  return (
    <div style={{ ...s.card, position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:color }} />
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div>
          <div style={{ fontSize:10, color:T.muted, textTransform:'uppercase', letterSpacing:1, marginBottom:6 }}>{label}</div>
          <div style={{ ...s.mono, fontSize:20, fontWeight:700, color }}>{value}</div>
          {sub && <div style={{ fontSize:11, color:T.muted, marginTop:3 }}>{sub}</div>}
        </div>
        <span style={{ fontSize:24 }}>{icon}</span>
      </div>
    </div>
  )
}

function Modal({ title, onClose, children }) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.75)', display:'flex',
      alignItems:'center', justifyContent:'center', zIndex:999, padding:16 }}>
      <div style={{ ...s.card, width:'100%', maxWidth:460, maxHeight:'90vh', overflowY:'auto' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18 }}>
          <h3 style={{ fontSize:15, fontWeight:700, color:'#fff' }}>{title}</h3>
          <button onClick={onClose} style={{ color:T.muted, fontSize:22, cursor:'pointer', background:'none', border:'none' }}>×</button>
        </div>
        {children}
      </div>
    </div>
  )
}

function Loader() {
  return <div style={{ display:'flex', justifyContent:'center', padding:32, color:T.muted, fontSize:13 }}>⏳ Carregando...</div>
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ user }) {
  const now = new Date()
  const [year, setYear] = useState(now.getFullYear())
  const [month, setMonth] = useState(now.getMonth()+1)
  const [bal, setBal] = useState(null)
  const [profile, setProfile] = useState(null)
  const [recent, setRecent] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    ;(async () => {
      const [{ data: p }, { data: b }] = await Promise.all([
        supabase.from('user_profiles').select('*').eq('id', user.id).single(),
        supabase.from('monthly_balance').select('*').eq('user_id', user.id).eq('year', year).eq('month', month).single(),
      ])
      setProfile(p); setBal(b)
      const { data: period } = await supabase.from('monthly_periods')
        .select('id').eq('user_id', user.id).eq('year', year).eq('month', month).single()
      if (period) {
        const { data: tx } = await supabase.from('transactions').select('*')
          .eq('user_id', user.id).eq('period_id', period.id).order('created_at', { ascending: false }).limit(7)
        setRecent(tx || [])
      } else setRecent([])
      setLoading(false)
    })()
  }, [user.id, year, month])

  const income = bal?.total_income||0, expenses = bal?.total_expenses||0
  const investments = bal?.total_investments||0, balance = bal?.balance||0
  const ePct = income>0?((expenses/income)*100).toFixed(1):0
  const iPct = income>0?((investments/income)*100).toFixed(1):0
  const tE = profile?.essential_target_pct||55
  const tI = profile?.investment_target_pct||30

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <div>
          <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Dashboard</h2>
          <p style={{ color:T.muted2, fontSize:13 }}>{MONTH_NAMES[month-1]} {year}</p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <select value={month} onChange={e => setMonth(+e.target.value)} style={{ ...s.input, width:110 }}>
            {MONTHS.map((m,i) => <option key={i} value={i+1}>{m}</option>)}
          </select>
          <select value={year} onChange={e => setYear(+e.target.value)} style={{ ...s.input, width:85 }}>
            {[2024,2025,2026,2027].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {loading ? <Loader /> : <>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:12 }}>
          <KPI label="Receita" value={fmt(income)} icon="💰" color={T.green} />
          <KPI label="Despesas" value={fmt(expenses)} sub={`${ePct}% da receita (meta ${tE}%)`}
            icon="💸" color={+ePct>tE?T.red:T.yellow} />
          <KPI label="Investimentos" value={fmt(investments)} sub={`${iPct}% (meta ${tI}%)`}
            icon="📈" color={+iPct<tI?T.red:T.green} />
          <KPI label="Saldo" value={fmt(balance)} icon={balance>=0?'✅':'⚠️'} color={balance>=0?T.green:T.red} />
        </div>

        <div style={s.card}>
          <div style={{ fontSize:11, color:T.muted2, fontWeight:600, textTransform:'uppercase', letterSpacing:1, marginBottom:14 }}>Metas do mês</div>
          {[
            { label:'Essencial', pct:+ePct, target:tE, color:+ePct>tE?T.red:T.green },
            { label:'Investimentos', pct:+iPct, target:tI, color:+iPct<tI?T.red:T.green },
          ].map(item => (
            <div key={item.label} style={{ marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                <span style={{ fontSize:13, color:T.muted2 }}>{item.label}</span>
                <span style={{ ...s.mono, fontSize:12, color:item.color }}>{item.pct}% / meta {item.target}%</span>
              </div>
              <div style={{ background:T.border, borderRadius:4, height:7 }}>
                <div style={{ width:Math.min(item.pct,100)+'%', background:item.color, borderRadius:4, height:'100%', transition:'width .5s' }} />
              </div>
            </div>
          ))}
        </div>

        <div style={s.card}>
          <div style={{ fontSize:11, color:T.muted2, fontWeight:600, textTransform:'uppercase', letterSpacing:1, marginBottom:14 }}>
            Lançamentos recentes
          </div>
          {recent.length===0
            ? <p style={{ color:T.muted, fontSize:13, textAlign:'center', padding:12 }}>Nenhum lançamento neste mês.</p>
            : recent.map(tx => (
              <div key={tx.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                padding:'9px 0', borderBottom:`1px solid ${T.border}` }}>
                <span style={{ fontSize:13, color:T.text, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {tx.description}
                </span>
                <div style={{ textAlign:'right', flexShrink:0, marginLeft:8 }}>
                  <div style={{ ...s.mono, fontSize:13, color:tx.type==='income'?T.green:T.red }}>
                    {tx.type==='income'?'+':'-'}{fmt(tx.amount_actual||tx.amount_planned)}
                  </div>
                  <div style={{ fontSize:10, color:tx.status==='paid'?T.green:T.yellow }}>
                    {tx.status==='paid'?'✓ pago':'pendente'}
                  </div>
                </div>
              </div>
            ))}
        </div>
      </>}
    </div>
  )
}

// ─── Transactions ─────────────────────────────────────────────────────────────
function Transactions({ user }) {
  const now = new Date()
  const [year, setYear] = useState(now.getFullYear())
  const [month, setMonth] = useState(now.getMonth()+1)
  const [list, setList] = useState([])
  const [cats, setCats] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [filter, setFilter] = useState('all')
  const emptyForm = { description:'', amount_planned:'', amount_actual:'', type:'expense',
    category_id:'', payment_method:'credit_card', status:'pending', transaction_date:'' }
  const [form, setForm] = useState(emptyForm)

  const getOrCreatePeriod = async () => {
    let { data: p } = await supabase.from('monthly_periods').select('id')
      .eq('user_id', user.id).eq('year', year).eq('month', month).single()
    if (!p) {
      const { data: created } = await supabase.from('monthly_periods')
        .insert({ user_id:user.id, year, month }).select().single()
      p = created
    }
    return p?.id
  }

  const load = useCallback(async () => {
    setLoading(true)
    const [{ data: c }, { data: period }] = await Promise.all([
      supabase.from('categories').select('*').eq('user_id', user.id),
      supabase.from('monthly_periods').select('id').eq('user_id', user.id).eq('year', year).eq('month', month).single(),
    ])
    setCats(c||[])
    if (!period) { setList([]); setLoading(false); return }
    let q = supabase.from('transactions').select('*').eq('user_id', user.id).eq('period_id', period.id).order('created_at', { ascending:false })
    if (filter!=='all') q = q.eq('type', filter)
    const { data: tx } = await q
    setList(tx||[])
    setLoading(false)
  }, [user.id, year, month, filter])

  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!form.description) return
    const period_id = await getOrCreatePeriod()
    if (!period_id) return
    await supabase.from('transactions').insert({
      user_id:user.id, period_id,
      description:form.description,
      amount_planned:parseFloat(form.amount_planned)||0,
      amount_actual:form.amount_actual?parseFloat(form.amount_actual):null,
      type:form.type, category_id:form.category_id||null,
      payment_method:form.payment_method, status:form.status,
      transaction_date:form.transaction_date||null,
    })
    setShowModal(false); setForm(emptyForm); load()
  }

  const remove = async (id) => { await supabase.from('transactions').delete().eq('id', id); load() }
  const markPaid = async (tx) => {
    await supabase.from('transactions').update({ status:'paid', amount_actual:tx.amount_actual||tx.amount_planned }).eq('id', tx.id)
    load()
  }

  const income = list.filter(t=>t.type==='income').reduce((a,t)=>a+(t.amount_actual||t.amount_planned),0)
  const expense = list.filter(t=>t.type==='expense').reduce((a,t)=>a+(t.amount_actual||t.amount_planned),0)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Transações</h2>
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
          <select value={month} onChange={e=>setMonth(+e.target.value)} style={{ ...s.input, width:110 }}>
            {MONTHS.map((m,i)=><option key={i} value={i+1}>{m}</option>)}
          </select>
          <select value={year} onChange={e=>setYear(+e.target.value)} style={{ ...s.input, width:85 }}>
            {[2024,2025,2026,2027].map(y=><option key={y} value={y}>{y}</option>)}
          </select>
          <button onClick={()=>setShowModal(true)} style={s.btnP}>+ Lançar</button>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10 }}>
        {[['RECEITAS',income,T.green],['DESPESAS',expense,T.red],['SALDO',income-expense,income-expense>=0?T.green:T.red]].map(([l,v,c])=>(
          <div key={l} style={{ ...s.card, textAlign:'center' }}>
            <div style={{ fontSize:10, color:T.muted, marginBottom:4 }}>{l}</div>
            <div style={{ ...s.mono, color:c, fontSize:16, fontWeight:700 }}>{fmt(v)}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
        {[['all','Todos'],['income','Receitas'],['expense','Despesas'],['investment','Invest.']].map(([v,l])=>(
          <button key={v} onClick={()=>setFilter(v)}
            style={{ padding:'6px 12px', borderRadius:6, fontSize:12, cursor:'pointer',
              background:filter===v?T.green+'22':T.surface2, color:filter===v?T.green:T.muted2,
              border:`1px solid ${filter===v?T.green+'44':T.border}` }}>
            {l}
          </button>
        ))}
      </div>

      <div style={{ ...s.card, padding:0, overflow:'hidden' }}>
        {loading ? <Loader /> : list.length===0
          ? <p style={{ color:T.muted, textAlign:'center', padding:28, fontSize:13 }}>Nenhuma transação encontrada.</p>
          : list.map(tx => {
            const cat = cats.find(c=>c.id===tx.category_id)
            return (
              <div key={tx.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                padding:'11px 14px', borderBottom:`1px solid ${T.border}`, gap:10 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, flex:1, minWidth:0 }}>
                  <span style={{ fontSize:18, flexShrink:0 }}>{cat?.icon||'💸'}</span>
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:13, color:T.text, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{tx.description}</div>
                    <div style={{ fontSize:11, color:T.muted }}>{cat?.name||tx.type} · {tx.payment_method}</div>
                  </div>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:8, flexShrink:0 }}>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ ...s.mono, fontSize:13, color:tx.type==='income'?T.green:T.red }}>
                      {tx.type==='income'?'+':'-'}{fmt(tx.amount_actual||tx.amount_planned)}
                    </div>
                    <div style={{ fontSize:10, color:tx.status==='paid'?T.green:T.yellow }}>
                      {tx.status==='paid'?'✓ pago':'pendente'}
                    </div>
                  </div>
                  {tx.status!=='paid' && (
                    <button onClick={()=>markPaid(tx)}
                      style={{ background:T.green+'22', color:T.green, padding:'4px 8px', borderRadius:6, fontSize:12, cursor:'pointer', border:'none' }}>✓</button>
                  )}
                  <button onClick={()=>remove(tx.id)} style={{ color:T.red, fontSize:18, cursor:'pointer', background:'none', border:'none' }}>×</button>
                </div>
              </div>
            )
          })}
      </div>

      {showModal && (
        <Modal title="Nova Transação" onClose={()=>setShowModal(false)}>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div>
              <label style={s.label}>Tipo</label>
              <div style={{ display:'flex', gap:6 }}>
                {[['income','Receita',T.green],['expense','Despesa',T.red],['investment','Investimento',T.blue]].map(([v,l,c])=>(
                  <button key={v} onClick={()=>setForm({...form,type:v})}
                    style={{ flex:1, padding:'7px 0', borderRadius:6, fontSize:12, fontWeight:600, cursor:'pointer',
                      background:form.type===v?c+'22':T.surface2, color:form.type===v?c:T.muted2,
                      border:`1px solid ${form.type===v?c+'44':T.border}` }}>{l}</button>
                ))}
              </div>
            </div>
            <div><label style={s.label}>Descrição</label>
              <input style={s.input} placeholder="Ex: Cartão Caixa Infinite" value={form.description}
                onChange={e=>setForm({...form,description:e.target.value})} />
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Previsto (R$)</label>
                <input style={s.input} type="number" placeholder="0.00" value={form.amount_planned}
                  onChange={e=>setForm({...form,amount_planned:e.target.value})} />
              </div>
              <div><label style={s.label}>Realizado (R$)</label>
                <input style={s.input} type="number" placeholder="0.00" value={form.amount_actual}
                  onChange={e=>setForm({...form,amount_actual:e.target.value})} />
              </div>
            </div>
            <div><label style={s.label}>Categoria</label>
              <select style={s.input} value={form.category_id} onChange={e=>setForm({...form,category_id:e.target.value})}>
                <option value="">Selecionar...</option>
                {cats.filter(c=>c.type===form.type).map(c=>(
                  <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
                ))}
              </select>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Pagamento</label>
                <select style={s.input} value={form.payment_method} onChange={e=>setForm({...form,payment_method:e.target.value})}>
                  {[['credit_card','Crédito'],['debit_card','Débito'],['pix','Pix'],['cash','Dinheiro'],['bank_transfer','TED/DOC'],['other','Outro']].map(([v,l])=>(
                    <option key={v} value={v}>{l}</option>
                  ))}
                </select>
              </div>
              <div><label style={s.label}>Status</label>
                <select style={s.input} value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
                  <option value="pending">Pendente</option>
                  <option value="paid">Pago</option>
                </select>
              </div>
            </div>
            <div><label style={s.label}>Data</label>
              <input style={s.input} type="date" value={form.transaction_date}
                onChange={e=>setForm({...form,transaction_date:e.target.value})} />
            </div>
            <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
              <button onClick={()=>setShowModal(false)} style={s.btnS}>Cancelar</button>
              <button onClick={save} style={s.btnP}>Salvar</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ─── Investments ──────────────────────────────────────────────────────────────
function Investments({ user }) {
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const emptyForm = { name:'', type:'short_term', institution:'', initial_amount:'',
    current_amount:'', target_amount:'', expected_return_pct:'', goal:'', start_date:'' }
  const [form, setForm] = useState(emptyForm)

  const load = async () => {
    setLoading(true)
    const { data } = await supabase.from('investments').select('*').eq('user_id', user.id).order('created_at', { ascending:false })
    setList(data||[]); setLoading(false)
  }
  useEffect(() => { load() }, [])

  const save = async () => {
    if (!form.name) return
    await supabase.from('investments').insert({
      user_id:user.id, name:form.name, type:form.type, institution:form.institution||null,
      initial_amount:parseFloat(form.initial_amount)||0,
      current_amount:form.current_amount?parseFloat(form.current_amount):null,
      target_amount:form.target_amount?parseFloat(form.target_amount):null,
      expected_return_pct:form.expected_return_pct?parseFloat(form.expected_return_pct):null,
      goal:form.goal||null, start_date:form.start_date||null, status:'active',
    })
    setShowModal(false); setForm(emptyForm); load()
  }
  const remove = async (id) => { await supabase.from('investments').delete().eq('id', id); load() }

  const tLabels = { short_term:'Curto prazo', mid_term:'Médio prazo', long_term:'Longo prazo',
    stocks:'Ações', crypto:'Cripto', real_estate:'Imóveis', other:'Outro' }
  const totalI = list.reduce((a,i)=>a+i.initial_amount,0)
  const totalC = list.reduce((a,i)=>a+(i.current_amount||i.initial_amount),0)
  const ret = totalI>0?(((totalC-totalI)/totalI)*100).toFixed(2):0

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Aplicações</h2>
        <button onClick={()=>setShowModal(true)} style={s.btnP}>+ Nova aplicação</button>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))', gap:12 }}>
        <KPI label="Total investido" value={fmt(totalI)} icon="💰" color={T.blue} />
        <KPI label="Saldo atual" value={fmt(totalC)} icon="📊" color={T.green} />
        <KPI label="Retorno" value={`${ret}%`} icon="📈" color={+ret>=0?T.green:T.red} />
      </div>
      <div style={{ ...s.card, padding:0, overflow:'hidden' }}>
        {loading ? <Loader /> : list.length===0
          ? <p style={{ color:T.muted, textAlign:'center', padding:28, fontSize:13 }}>Nenhuma aplicação cadastrada.</p>
          : list.map(inv => {
            const r = inv.initial_amount>0?((((inv.current_amount||inv.initial_amount)-inv.initial_amount)/inv.initial_amount)*100).toFixed(2):0
            const prog = inv.target_amount?Math.min(((inv.current_amount||inv.initial_amount)/inv.target_amount)*100,100).toFixed(0):null
            return (
              <div key={inv.id} style={{ padding:'14px 16px', borderBottom:`1px solid ${T.border}` }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                  <div>
                    <div style={{ fontSize:14, fontWeight:600, color:'#fff' }}>{inv.name}</div>
                    <div style={{ fontSize:11, color:T.muted }}>{tLabels[inv.type]} · {inv.institution||'—'}</div>
                    {inv.goal && <div style={{ fontSize:11, color:T.blue, marginTop:2 }}>🎯 {inv.goal}</div>}
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ ...s.mono, fontSize:16, color:T.green, fontWeight:700 }}>{fmt(inv.current_amount||inv.initial_amount)}</div>
                    <div style={{ fontSize:11, color:+r>=0?T.green:T.red }}>{r}% retorno</div>
                    <button onClick={()=>remove(inv.id)} style={{ color:T.red, fontSize:12, cursor:'pointer', background:'none', border:'none', marginTop:4 }}>remover</button>
                  </div>
                </div>
                {prog && (
                  <div style={{ marginTop:10 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                      <span style={{ fontSize:11, color:T.muted }}>Meta: {fmt(inv.target_amount)}</span>
                      <span style={{ fontSize:11, color:T.green }}>{prog}%</span>
                    </div>
                    <div style={{ background:T.border, borderRadius:4, height:6 }}>
                      <div style={{ width:prog+'%', background:T.green, borderRadius:4, height:'100%' }} />
                    </div>
                  </div>
                )}
              </div>
            )
          })}
      </div>
      {showModal && (
        <Modal title="Nova Aplicação" onClose={()=>setShowModal(false)}>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div><label style={s.label}>Nome</label>
              <input style={s.input} placeholder="Ex: Previdência Inter" value={form.name}
                onChange={e=>setForm({...form,name:e.target.value})} />
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Tipo</label>
                <select style={s.input} value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
                  {Object.entries(tLabels).map(([v,l])=><option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              <div><label style={s.label}>Instituição</label>
                <input style={s.input} placeholder="Inter, XP, Nubank..." value={form.institution}
                  onChange={e=>setForm({...form,institution:e.target.value})} />
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Valor inicial (R$)</label>
                <input style={s.input} type="number" value={form.initial_amount}
                  onChange={e=>setForm({...form,initial_amount:e.target.value})} />
              </div>
              <div><label style={s.label}>Saldo atual (R$)</label>
                <input style={s.input} type="number" value={form.current_amount}
                  onChange={e=>setForm({...form,current_amount:e.target.value})} />
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Meta (R$)</label>
                <input style={s.input} type="number" value={form.target_amount}
                  onChange={e=>setForm({...form,target_amount:e.target.value})} />
              </div>
              <div><label style={s.label}>Retorno esperado %</label>
                <input style={s.input} type="number" placeholder="12.5" value={form.expected_return_pct}
                  onChange={e=>setForm({...form,expected_return_pct:e.target.value})} />
              </div>
            </div>
            <div><label style={s.label}>Objetivo</label>
              <input style={s.input} placeholder="Casa nova, Aposentadoria..." value={form.goal}
                onChange={e=>setForm({...form,goal:e.target.value})} />
            </div>
            <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
              <button onClick={()=>setShowModal(false)} style={s.btnS}>Cancelar</button>
              <button onClick={save} style={s.btnP}>Salvar</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ─── Goals ────────────────────────────────────────────────────────────────────
function Goals({ user }) {
  const [list, setList] = useState([])
  const [invList, setInvList] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const emptyForm = { title:'', target_amount:'', current_amount:'0', deadline:'', category:'other', investment_id:'' }
  const [form, setForm] = useState(emptyForm)

  const load = async () => {
    setLoading(true)
    const [{ data: d }, { data: inv }] = await Promise.all([
      supabase.from('financial_goals').select('*').eq('user_id', user.id).order('created_at', { ascending:false }),
      supabase.from('investments').select('id,name').eq('user_id', user.id),
    ])
    setList(d||[]); setInvList(inv||[]); setLoading(false)
  }
  useEffect(() => { load() }, [])

  const save = async () => {
    if (!form.title) return
    await supabase.from('financial_goals').insert({
      user_id:user.id, title:form.title, category:form.category,
      target_amount:parseFloat(form.target_amount)||0,
      current_amount:parseFloat(form.current_amount)||0,
      deadline:form.deadline||null, investment_id:form.investment_id||null, status:'active',
    })
    setShowModal(false); setForm(emptyForm); load()
  }
  const remove = async (id) => { await supabase.from('financial_goals').delete().eq('id', id); load() }

  const catEmoji = { emergency_fund:'🛡️', property:'🏠', vehicle:'🚗',
    travel:'✈️', education:'📚', retirement:'🏖️', other:'🎯' }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Metas Financeiras</h2>
        <button onClick={()=>setShowModal(true)} style={s.btnP}>+ Nova meta</button>
      </div>
      {loading ? <Loader /> : list.length===0
        ? <div style={{ ...s.card, textAlign:'center', padding:32, color:T.muted, fontSize:13 }}>Nenhuma meta cadastrada.</div>
        : <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:12 }}>
          {list.map(goal => {
            const pct = goal.target_amount>0?Math.min((goal.current_amount/goal.target_amount)*100,100).toFixed(0):0
            return (
              <div key={goal.id} style={s.card}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:12 }}>
                  <div>
                    <span style={{ fontSize:24 }}>{catEmoji[goal.category]||'🎯'}</span>
                    <div style={{ fontSize:14, fontWeight:600, color:'#fff', marginTop:4 }}>{goal.title}</div>
                    {goal.deadline && <div style={{ fontSize:11, color:T.muted }}>até {new Date(goal.deadline).toLocaleDateString('pt-BR')}</div>}
                  </div>
                  <button onClick={()=>remove(goal.id)} style={{ color:T.red, fontSize:18, cursor:'pointer', background:'none', border:'none' }}>×</button>
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                  <span style={{ ...s.mono, fontSize:16, color:T.green, fontWeight:700 }}>{fmt(goal.current_amount)}</span>
                  <span style={{ ...s.mono, fontSize:13, color:T.muted }}>{fmt(goal.target_amount)}</span>
                </div>
                <div style={{ background:T.border, borderRadius:6, height:8 }}>
                  <div style={{ width:pct+'%', background:+pct>=100?T.green:T.blue, borderRadius:6, height:'100%', transition:'width .5s' }} />
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', marginTop:5 }}>
                  <span style={{ fontSize:11, color:T.muted2 }}>{pct}%</span>
                  <span style={{ fontSize:11, color:T.muted }}>Faltam {fmt(goal.target_amount-goal.current_amount)}</span>
                </div>
              </div>
            )
          })}
        </div>}
      {showModal && (
        <Modal title="Nova Meta" onClose={()=>setShowModal(false)}>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div><label style={s.label}>Título</label>
              <input style={s.input} placeholder="Ex: Entrada da casa" value={form.title}
                onChange={e=>setForm({...form,title:e.target.value})} />
            </div>
            <div><label style={s.label}>Categoria</label>
              <select style={s.input} value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
                {Object.entries(catEmoji).map(([v,emoji])=>(
                  <option key={v} value={v}>{emoji} {v.replace(/_/g,' ')}</option>
                ))}
              </select>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              <div><label style={s.label}>Valor alvo (R$)</label>
                <input style={s.input} type="number" value={form.target_amount}
                  onChange={e=>setForm({...form,target_amount:e.target.value})} />
              </div>
              <div><label style={s.label}>Já tenho (R$)</label>
                <input style={s.input} type="number" value={form.current_amount}
                  onChange={e=>setForm({...form,current_amount:e.target.value})} />
              </div>
            </div>
            <div><label style={s.label}>Prazo</label>
              <input style={s.input} type="date" value={form.deadline}
                onChange={e=>setForm({...form,deadline:e.target.value})} />
            </div>
            {invList.length>0 && (
              <div><label style={s.label}>Vincular aplicação</label>
                <select style={s.input} value={form.investment_id} onChange={e=>setForm({...form,investment_id:e.target.value})}>
                  <option value="">Nenhuma</option>
                  {invList.map(i=><option key={i.id} value={i.id}>{i.name}</option>)}
                </select>
              </div>
            )}
            <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
              <button onClick={()=>setShowModal(false)} style={s.btnS}>Cancelar</button>
              <button onClick={save} style={s.btnP}>Salvar</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ─── Reports ──────────────────────────────────────────────────────────────────
function Reports({ user }) {
  const [year, setYear] = useState(new Date().getFullYear())
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    supabase.from('monthly_balance').select('*').eq('user_id', user.id).eq('year', year).order('month')
      .then(({ data: d }) => { setData(d||[]); setLoading(false) })
  }, [user.id, year])

  const totalI=data.reduce((a,r)=>a+(r.total_income||0),0)
  const totalE=data.reduce((a,r)=>a+(r.total_expenses||0),0)
  const totalInv=data.reduce((a,r)=>a+(r.total_investments||0),0)
  const totalB=data.reduce((a,r)=>a+(r.balance||0),0)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Relatório {year}</h2>
        <select value={year} onChange={e=>setYear(+e.target.value)} style={{ ...s.input, width:85 }}>
          {[2024,2025,2026,2027].map(y=><option key={y} value={y}>{y}</option>)}
        </select>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))', gap:12 }}>
        <KPI label="Receita anual" value={fmt(totalI)} icon="💰" color={T.green} />
        <KPI label="Despesas" value={fmt(totalE)} icon="💸" color={T.red} />
        <KPI label="Investido" value={fmt(totalInv)} icon="📈" color={T.blue} />
        <KPI label="Saldo total" value={fmt(totalB)} icon="🏦" color={totalB>=0?T.green:T.red} />
      </div>
      <div style={{ ...s.card, padding:0, overflow:'auto' }}>
        {loading ? <Loader /> :
          <table style={{ width:'100%', borderCollapse:'collapse', minWidth:500 }}>
            <thead>
              <tr style={{ background:T.surface2 }}>
                {['Mês','Receita','Despesas','Invest.','Saldo','Ess.%'].map(h=>(
                  <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:10,
                    color:T.muted, textTransform:'uppercase', letterSpacing:1, fontWeight:500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.length===0
                ? <tr><td colSpan={6} style={{ padding:24, textAlign:'center', color:T.muted, fontSize:13 }}>Nenhum dado para {year}.</td></tr>
                : data.map(row => {
                  const ePct = row.total_income>0?((row.total_expenses/row.total_income)*100).toFixed(1):'—'
                  return (
                    <tr key={row.month} style={{ borderTop:`1px solid ${T.border}` }}>
                      <td style={{ padding:'11px 14px', color:T.muted2, fontSize:13 }}>{MONTH_NAMES[row.month-1]}</td>
                      <td style={{ padding:'11px 14px', ...s.mono, fontSize:13, color:T.green }}>{fmt(row.total_income)}</td>
                      <td style={{ padding:'11px 14px', ...s.mono, fontSize:13, color:T.red }}>{fmt(row.total_expenses)}</td>
                      <td style={{ padding:'11px 14px', ...s.mono, fontSize:13, color:T.blue }}>{fmt(row.total_investments)}</td>
                      <td style={{ padding:'11px 14px', ...s.mono, fontSize:13, color:row.balance>=0?T.green:T.red }}>{fmt(row.balance)}</td>
                      <td style={{ padding:'11px 14px', ...s.mono, fontSize:12, color:+ePct>55?T.red:T.green }}>{ePct}%</td>
                    </tr>
                  )
                })}
            </tbody>
          </table>}
      </div>
    </div>
  )
}

// ─── Settings ─────────────────────────────────────────────────────────────────
function Settings({ user }) {
  const [form, setForm] = useState({ full_name:'', monthly_income_base:'',
    essential_target_pct:55, investment_target_pct:30, leisure_target_pct:10, education_target_pct:5 })
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    supabase.from('user_profiles').select('*').eq('id', user.id).single()
      .then(({ data }) => { if (data) setForm(f => ({...f,...data})) })
  }, [user.id])

  const save = async () => {
    await supabase.from('user_profiles').upsert({
      id:user.id, full_name:form.full_name,
      monthly_income_base:parseFloat(form.monthly_income_base)||null,
      essential_target_pct:+form.essential_target_pct,
      investment_target_pct:+form.investment_target_pct,
      leisure_target_pct:+form.leisure_target_pct,
      education_target_pct:+form.education_target_pct,
    })
    setSaved(true); setTimeout(()=>setSaved(false),2500)
  }

  const total = +form.essential_target_pct + +form.investment_target_pct +
    +form.leisure_target_pct + +form.education_target_pct

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16, maxWidth:520 }}>
      <h2 style={{ fontSize:20, fontWeight:700, color:'#fff' }}>Configurações</h2>
      <div style={s.card}>
        <div style={{ fontSize:11, color:T.muted2, fontWeight:600, textTransform:'uppercase', letterSpacing:1, marginBottom:14 }}>Perfil</div>
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div><label style={s.label}>Nome</label>
            <input style={s.input} value={form.full_name||''} onChange={e=>setForm({...form,full_name:e.target.value})} />
          </div>
          <div><label style={s.label}>Renda base mensal (R$)</label>
            <input style={s.input} type="number" value={form.monthly_income_base||''}
              onChange={e=>setForm({...form,monthly_income_base:e.target.value})} />
          </div>
        </div>
      </div>
      <div style={s.card}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div style={{ fontSize:11, color:T.muted2, fontWeight:600, textTransform:'uppercase', letterSpacing:1 }}>Distribuição %</div>
          <span style={{ ...s.mono, fontSize:12, color:total===100?T.green:T.red }}>
            {total}% {total!==100?'⚠️ deve ser 100%':'✓'}
          </span>
        </div>
        {[['essential_target_pct','🏠 Essencial'],['investment_target_pct','📈 Investimentos'],
          ['leisure_target_pct','🎉 Lazer'],['education_target_pct','📚 Educação']].map(([k,l])=>(
          <div key={k} style={{ marginBottom:14 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
              <label style={{ ...s.label, marginBottom:0 }}>{l}</label>
              <span style={{ ...s.mono, fontSize:13, color:T.green }}>{form[k]}%</span>
            </div>
            <input type="range" min={0} max={100} value={form[k]}
              onChange={e=>setForm({...form,[k]:+e.target.value})}
              style={{ width:'100%', accentColor:T.green }} />
          </div>
        ))}
      </div>
      <button onClick={save} style={{ ...s.btnP, alignSelf:'flex-start' }}>
        {saved?'✓ Salvo!':'Salvar configurações'}
      </button>
    </div>
  )
}

// ─── App root ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null)
  const [booting, setBooting] = useState(true)
  const [active, setActive] = useState('dashboard')
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user || null)
      setBooting(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user || null)
    })
    return () => subscription.unsubscribe()
  }, [])

  const logout = async () => {
    await supabase.auth.signOut()
    setUser(null)
  }

  if (booting) return (
    <div style={{ ...s.page, display:'flex', alignItems:'center', justifyContent:'center' }}>
      <span style={{ color:T.muted2 }}>Iniciando...</span>
    </div>
  )

  if (!user) return <AuthScreen onAuth={setUser} />

  const sideW = collapsed ? 56 : 210
  const screens = { dashboard:Dashboard, transactions:Transactions,
    investments:Investments, goals:Goals, reports:Reports, settings:Settings }
  const Screen = screens[active] || Dashboard

  return (
    <div style={s.page}>
      <style>{`*, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:5px; } ::-webkit-scrollbar-thumb { background:#272d42; border-radius:3px; }
        select option { background:#1e2335; color:#e2e8f0; }`}
      </style>
      <Sidebar active={active} setActive={setActive} onLogout={logout}
        collapsed={collapsed} setCollapsed={setCollapsed} />
      <main style={{ marginLeft:sideW, padding:'24px 22px', minHeight:'100vh', transition:'margin-left .2s' }}>
        <Screen user={user} />
      </main>
    </div>
  )
}
